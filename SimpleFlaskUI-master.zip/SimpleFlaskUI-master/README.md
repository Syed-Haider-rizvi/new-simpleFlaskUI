# CI/CD With Jenkins, Python, Docker

- Python 3x, PyCharm
- Docker, DockerHub account
- Git, and git-bash or GitHubDesktop
- GitHub account
- Jenkins Server on Linux
- Linux Server with docker installed

[Tutorial here](https://youtu.be/jHkbtzemsGs)
